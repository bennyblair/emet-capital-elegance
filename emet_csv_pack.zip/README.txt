
This workbook is the single source of truth for Emet Capital content automation.

Key tabs:
- Section Map: menu label ↔ section_key ↔ listing/post URLs
- Content Type Rules: maps content types to section_key
- Posting Schedule (SOT): 365×2 calendar with canonical section/post URLs
- AI Feed (Daily): FULL article rows with json_header + body_html + proposed_link_out_json
- Articles (Full+Links): same as AI Feed plus breadcrumb and metrics
- Interlink Suggestions / interlinks.csv: long table and CSV-ready export
- Article QA / Combined / Summary: quality and alignment checks
- Automation Prompt: system instructions for your runner
- github_action.yml / publish_from_sot.py / apply_interlinks.py: tooling

Publishing flow (daily):
1) Runner reads 'AI Feed (Daily)', finds today's Morning/Afternoon rows.
2) Ensures JSON header meta.section & meta.url match section_key/post_url.
3) Publishes body_html at post_url; includes schema + breadcrumb.
4) Writes proposed_link_out_json into interlinking.link_out (or run link graph).
5) Updates sitemap & listings.
