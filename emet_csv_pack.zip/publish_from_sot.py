#!/usr/bin/env python3
import os, re, json, pandas as pd
from datetime import date
from pathlib import Path

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--sot", required=True)
    ap.add_argument("--articles-dir", required=True)
    ap.add_argument("--published-dir", required=True)
    args = ap.parse_args()

    today = date.today().isoformat()
    xls = pd.ExcelFile(args.sot)
    feed = pd.read_excel(xls, 'AI Feed (Daily)')
    # Select the two rows matching today's date
    today_rows = feed[feed['date'] == today].copy()
    if today_rows.empty:
        print(f"No rows for {today} in AI Feed (Daily).")
        return

    src_dir = Path(args.articles_dir)
    dst_dir = Path(args.published_dir); dst_dir.mkdir(parents=True, exist_ok=True)

    for _, row in today_rows.iterrows():
        # Filename may vary; prefer URL slug and slot to compose expected filename
        url = row['post_url']
        slug = str(url).split('/')[-1]
        slot = row['slot']
        slot_num = '1' if str(slot).lower().startswith('m') else '2'
        fname = f"{today}_{slot_num}--{slug}.md"
        src = src_dir / fname
        if not src.exists():
            print(f"Missing source file: {src}")
            # As fallback, synthesise file from json_header + body_html
            header = json.loads(row['json_header'])
            header['meta']['url'] = row['post_url']
            header['meta']['section'] = row['section_key']
            header['meta']['title'] = row['title']
            if 'proposed_link_out_json' in row and isinstance(row['proposed_link_out_json'], str) and row['proposed_link_out_json'].strip():
                try:
                    header.setdefault('interlinking', {})['link_out'] = json.loads(row['proposed_link_out_json'])
                except Exception:
                    pass
            md = "```json\n" + json.dumps(header, ensure_ascii=False, indent=2) + "\n```\n\n" + row['body_html']
            (src_dir / fname).write_text(md, encoding='utf-8')
            src = src_dir / fname

        # Move/copy to published
        dst = dst_dir / fname
        dst.write_text(src.read_text(encoding='utf-8'), encoding='utf-8')
        print(f"Published: {dst}")

if __name__ == "__main__":
    main()
