#!/usr/bin/env python3
import os, re, json, pandas as pd
from pathlib import Path

def parse_header_and_body(text: str):
    m = re.search(r"^```json\s*(\{.*?\})\s*```", text, flags=re.DOTALL|re.IGNORECASE)
    if not m: 
        return {}, text, ""
    header = json.loads(m.group(1))
    body = text[m.end():].lstrip()
    return header, body, m.group(1)

def write_header_and_body(header: dict, body: str) -> str:
    return "```json\n" + json.dumps(header, ensure_ascii=False, indent=2) + "\n```\n\n" + body

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="interlinks.csv")
    ap.add_argument("--dir", required=True, help="folder with markdown files")
    args = ap.parse_args()

    df = pd.read_csv(args.csv)
    grouped = df.groupby("source_file")
    base = Path(args.dir)
    for fname, group in grouped:
        path = base / fname
        if not path.exists(): 
            print(f"skip (missing): {fname}")
            continue
        text = path.read_text(encoding="utf-8")
        header, body, raw = parse_header_and_body(text)
        inter = header.setdefault("interlinking", {})
        inter["link_out"] = [{"url": r["target_url"], "anchor": r["anchor"], "relation": r["relation"]}
                             for _, r in group.iterrows()]
        out = write_header_and_body(header, body)
        path.write_text(out, encoding="utf-8")
        print(f"updated: {fname} ({len(inter['link_out'])} links)")

if __name__ == "__main__":
    main()
