#!/usr/bin/env python3
import os, re, json, random, math
from pathlib import Path

def strip_top_json(text):
    m = re.search(r"^```json\s*(\{.*?\})\s*```", text, flags=re.DOTALL|re.IGNORECASE)
    if m:
        return m.group(1), text[m.end():].lstrip()
    return "{}", text

def html_to_text(html):
    txt = re.sub(r"<[^>]+>", " ", html)
    txt = re.sub(r"\s+", " ", txt)
    return txt.strip()

def p(t): return f"<p>{t}</p>"
def h2(t): return f"<h2>{t}</h2>"
def ul(items): return "<ul>" + "".join(f"<li>{i}</li>" for i in items) + "</ul>"
def table(rows): return "<table><tbody>" + "".join(f"<tr><th>{a}</th><td>{b}</td></tr>" for a,b in rows) + "</tbody></table>"

INDUSTRIES = [
    ("Construction & trades", ["Progress claims timing", "Retention and variations", "Subcontractor payments", "Plant & equipment purchases"]),
    ("Wholesale & import", ["Long shipping lead times", "FX and supplier deposits", "Customs and duty windows", "Inventory bulges pre‑peak"]),
    ("Manufacturing", ["Lumpy raw material buys", "Production cycles vs debtor terms", "Asset‑backed lines for machinery", "Maintenance shutdowns"]),
    ("Property & real estate", ["Settlement bridging", "Residual stock clearances", "Leasing incentives", "Fitout costs"]),
]
STATES = ["NSW", "VIC", "QLD", "WA", "SA", "TAS", "ACT", "NT"]

PARA_POOL = [
    "We start by mapping the lender set for your scenario and removing options that don’t match your timetable or security profile.",
    "Credit teams respond well to clear summaries: who you are, what you need, security available, and how funds are repaid.",
    "Price is only one lever: small tweaks to LVR, term, or interest prepayment can reduce total cost of funds materially.",
    "If the exit is a refinance, we’ll sanity‑check bank appetite and timing so the bridge doesn’t overrun.",
    "For deals touching multiple properties, priority and consent order matters — we’ll position this early to avoid last‑minute delays.",
    "Short timelines favour lenders with in‑house legals and desktop valuations; longer timelines can open sharper pricing.",
    "Where servicing is thin, we’ll emphasise asset strength and mitigants rather than push a cash‑flow story that won’t pass.",
    "We’ll draft a simple data room checklist and drive the process so you can keep running the business.",
    "When a valuation is required, booking early and providing leases/outgoings reduces rework and queries.",
    "If there are arrears (ATO or suppliers), we normalise them in the pack, including statements and a plan to clear them on settlement.",
    "In second mortgages, priority and consent are often the critical path — addressing these upfront saves a week.",
    "Caveat‑backed options can be faster but often dearer; we’ll compare the true cash cost across realistic timelines.",
    "For trade and import cycles, matching tenor to shipping and debtor terms keeps working capital stable.",
    "We’ll model a base case and a slower exit case to make sure the structure remains safe."
]

def expand_to_target(body_html, kw, pillar, target_words, seed):
    rnd = random.Random(seed)
    def wc(s): return len(re.sub(r"<[^>]+>"," ",s).split())
    out = body_html

    # Big structured blocks (once)
    blocks = []

    # Industry scenarios
    blocks.append(h2("Industry‑specific scenarios"))
    items = []
    for name, bullets in INDUSTRIES:
        items.append(f"<strong>{name}.</strong> " + "; ".join(bullets) + ".")
    blocks.append(ul(items))

    # State nuances
    blocks.append(h2("State‑by‑state nuances (high level)"))
    blocks.append(ul([f"{s}: typical differences in turnaround times, local valuation coverage and lender appetite." for s in STATES]))

    # Underwriting deep dive
    blocks.append(h2("Underwriting lens in practice"))
    deep = [
        "Security layers (1st vs 2nd mortgage, caveat, GSA) and priority/consents",
        "LVR vs asset quality; lease WALE and income coverage where relevant",
        "Serviceability vs asset‑based assessment; interest‑prepaid structures",
        "Conditions precedent (valuations, QS, titles, insurances) and common waivers",
        "Covenants and information undertakings that appear in term sheets"
    ]
    blocks.append(ul(deep))

    # Example pricing breakdown
    blocks.append(h2("Illustrative cost breakdown (example only)"))
    rows = [
        ("Facility size", "$750,000"),
        ("Term", "6 months, interest‑only"),
        ("Interest (illustrative)", "1.4% per month, paid monthly or prepaid"),
        ("Establishment", "2.5% + legal/valuation at cost"),
        ("Other", "Disbursements, settlement agent, PPSR, title fees"),
        ("Estimated total cost (ex‑GST)", "Depends on days used; always scenario‑specific")
    ]
    blocks.append(table(rows))
    blocks.append(p("These indicative numbers vary by lender, security quality and the exit plan."))

    # Alternatives
    blocks.append(h2("Alternatives to consider"))
    alts = [
        "Invoice finance for debtor‑backed working capital",
        "Trade finance for supplier deposits and shipping windows",
        "Equipment finance where the asset holds value",
        "Refinance of the primary facility (if bank appetite/stability allows)"
    ]
    blocks.append(ul(alts))

    # Mistakes
    blocks.append(h2("Common mistakes that slow deals"))
    mistakes = [
        "Unclear exit or timeline",
        "Missing title/rates docs or outdated valuations",
        "Unverified arrears (ATO, suppliers) that emerge late",
        "Over‑optimistic LVR expectations vs asset quality"
    ]
    blocks.append(ul(mistakes))

    # Practical tips
    blocks.append(h2("Practical tips to improve pricing and speed"))
    guidance = [
        "Start your data room early: photo ID, ABN, bank statements, BAS, rates notice, title search, lease docs and any valuations you have.",
        "Be explicit on use‑of‑funds and exit steps with dates; this shortens credit cycles and reduces conditions.",
        "Ask for two structures: lowest‑cost and fastest‑settling — you can decide based on deadlines and total cost of funds.",
        "If there are arrears, provide statements upfront; surprises late in the process add risk margin."
    ]
    blocks.append(ul(guidance))

    out += "\n" + "\n".join(blocks)

    # Keep adding paragraphs from pool until target reached
    i = 0
    while wc(out) < target_words and i < 1000:
        para = PARA_POOL[rnd.randrange(len(PARA_POOL))]
        out += "\n" + p(para)
        i += 1

    return out

def process_file(src_path: Path, dst_path: Path, target_min=1600, target_max=2100):
    text = src_path.read_text(encoding='utf-8')
    head_json, body = strip_top_json(text)
    try:
        header = json.loads(head_json) if head_json.strip().startswith("{") else {"meta":{}}
    except Exception:
        header = {"meta":{}}
    meta = header.setdefault("meta", {})
    kw = meta.get("target_keyword") or src_path.stem
    pillar = meta.get("pillar","")
    slug = src_path.stem.split("--")[-1]
    rnd = random.Random(slug)
    target_words = rnd.randint(target_min, target_max)

    # expand
    body = expand_to_target(body, kw, pillar, target_words, seed=slug)

    # update word count target
    meta["word_count_target"] = target_words

    out_text = "```json\n" + json.dumps(header, ensure_ascii=False, indent=2) + "\n```\n\n" + body
    dst_path.write_text(out_text, encoding='utf-8')

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--in-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--min", type=int, default=1600)
    ap.add_argument("--max", type=int, default=2100)
    args = ap.parse_args()
    inp = Path(args.in_dir); out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    files = sorted([p for p in inp.glob("*.md")])
    for p in files:
        process_file(p, out / p.name, target_min=args.min, target_max=args.max)

if __name__ == "__main__":
    main()
